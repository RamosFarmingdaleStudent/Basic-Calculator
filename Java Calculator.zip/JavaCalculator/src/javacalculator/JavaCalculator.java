/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javacalculator;

import java.util.Scanner;

/**
 *
 * @author Owner
 */
public class JavaCalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num1 = 0;
        int num2 = 0;
        char op;
        double answer = 0.0;
        
        Scanner scnr = new Scanner(System.in);
        
        System.out.println("Enter first number: ");
        num1 = scnr.nextInt();
        System.out.println("Enter second number: ");
        num2 = scnr.nextInt();
        
        System.out.println("Which operator to use?");
        op = scnr.next().charAt(0);
        
        switch (op){
            case '+': answer = num1 + num2;
            break;
            case '-': answer = num1 - num2;
            break;
            case '*': answer = num1 * num2;
            break;
            case '/': answer = num1 / num2;
            break;
        }
        System.out.println(num1 + " " + op + " " + num2 + " = " + answer);
    }
    
}
